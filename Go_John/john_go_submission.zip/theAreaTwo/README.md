# theAreaTwo
Mockup website of theAreatwo.com - 
Created by: John Regner Go - Created on: November 20, 2020

Instructions:
1. Clone this repo to your own computer to make a copy of the files.
2. Open the index.html file with your chosen browser.
3. Enjoy!

Website template by https://designmodo.com/slides/
